import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Session setup
  app.use(session({
    store: new PostgresSessionStore({ pool, createTableIfMissing: true }),
    secret: process.env.SESSION_SECRET || "dfap-secret-key",
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 30 * 24 * 60 * 60 * 1000 } // 30 days
  }));

  // Auth Routes

  app.post(api.auth.sendOtp.path, async (req, res) => {
    try {
      const { mobileNumber } = api.auth.sendOtp.input.parse(req.body);
      
      // Simulate OTP generation (always use 123456 for dev/demo simplicity or random)
      // In a real app, this would use an SMS gateway
      const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
      const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 minutes

      await storage.createOtp(mobileNumber, otpCode, expiresAt);
      
      console.log(`[OTP] Sent to ${mobileNumber}: ${otpCode}`); // Log for dev use

      res.json({ 
        message: "OTP sent successfully", 
        expiresAt: expiresAt.toISOString(),
        devOtp: otpCode // Temporary: send OTP in response for development
      });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Failed to send OTP" });
    }
  });

  app.post(api.auth.verifyOtp.path, async (req, res) => {
    try {
      const { mobileNumber, otpCode } = api.auth.verifyOtp.input.parse(req.body);
      
      const isValid = await storage.verifyOtp(mobileNumber, otpCode);
      
      if (!isValid) {
        return res.status(401).json({ message: "Invalid or expired OTP" });
      }

      // Check if user exists
      let user = await storage.getUserByMobile(mobileNumber);
      let isNewUser = false;

      if (!user) {
        // Create tentative user or just mark session as "verified mobile" waiting for registration
        // For simplicity, we'll create a user record if we have one, but if not we might need to wait for register-details.
        // Let's check the flow: The prompt says "Role Selection after OTP verification".
        // So we can establish a session for the mobile number now.
        isNewUser = true;
        // We don't create the user DB record yet, or we create a partial one? 
        // Let's create a placeholder user or handle it in register-details.
        // Better: Create user with just mobile number now.
        user = await storage.createUser({ mobileNumber });
      }

      // Set session
      (req.session as any).userId = user.id;
      
      res.json({ message: "OTP verified", user, isNewUser });
    } catch (err) {
       if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Failed to verify OTP" });
    }
  });

  app.post(api.auth.registerDetails.path, async (req, res) => {
    if (!(req.session as any).userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    try {
      const input = api.auth.registerDetails.input.parse(req.body);
      const userId = (req.session as any).userId;
      
      const updatedUser = await storage.updateUser(userId, {
        ...input,
        isVerified: true
      });

      res.json(updatedUser);
    } catch (err) {
       if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Failed to update profile" });
    }
  });

  app.post(api.auth.logout.path, (req, res) => {
    req.session.destroy((err) => {
      if (err) return res.status(500).json({ message: "Logout failed" });
      res.json({ message: "Logged out" });
    });
  });

  app.get(api.auth.me.path, async (req, res) => {
    if (!(req.session as any).userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    const user = await storage.getUser((req.session as any).userId);
    if (!user) return res.status(401).json({ message: "User not found" });
    res.json(user);
  });

  return httpServer;
}

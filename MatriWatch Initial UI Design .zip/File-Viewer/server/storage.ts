import { db } from "./db";
import { users, otpVerifications, type User, type InsertUser, type OtpVerification } from "@shared/schema";
import { eq, and, gt } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByMobile(mobileNumber: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<InsertUser>): Promise<User>;
  
  createOtp(mobileNumber: string, otpCode: string, expiresAt: Date): Promise<void>;
  verifyOtp(mobileNumber: string, otpCode: string): Promise<boolean>;
  sessionStore: any; // For express-session
}

export class DatabaseStorage implements IStorage {
  sessionStore: any;

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByMobile(mobileNumber: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.mobileNumber, mobileNumber));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<InsertUser>): Promise<User> {
    const [user] = await db.update(users).set(updates).where(eq(users.id, id)).returning();
    return user;
  }

  async createOtp(mobileNumber: string, otpCode: string, expiresAt: Date): Promise<void> {
    await db.insert(otpVerifications).values({
      mobileNumber,
      otpCode,
      expiresAt,
    });
  }

  async verifyOtp(mobileNumber: string, otpCode: string): Promise<boolean> {
    const [record] = await db.select()
      .from(otpVerifications)
      .where(and(
        eq(otpVerifications.mobileNumber, mobileNumber),
        eq(otpVerifications.otpCode, otpCode),
        gt(otpVerifications.expiresAt, new Date()),
        eq(otpVerifications.isVerified, false)
      ))
      .orderBy(otpVerifications.expiresAt); // Get the latest valid one? Actually we just need any valid one.

    if (record) {
      // Mark as verified
      await db.update(otpVerifications)
        .set({ isVerified: true })
        .where(eq(otpVerifications.id, record.id));
      return true;
    }
    return false;
  }
}

export const storage = new DatabaseStorage();

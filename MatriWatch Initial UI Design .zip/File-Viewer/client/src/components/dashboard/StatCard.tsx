import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  trend?: "up" | "down" | "neutral";
  trendValue?: string;
  color?: "blue" | "green" | "orange" | "purple";
  className?: string;
}

export function StatCard({ 
  title, 
  value, 
  subtitle, 
  icon: Icon, 
  trend, 
  trendValue, 
  color = "blue",
  className 
}: StatCardProps) {
  
  const colorStyles = {
    blue: "bg-blue-50 text-blue-600",
    green: "bg-green-50 text-green-600",
    orange: "bg-orange-50 text-orange-600",
    purple: "bg-purple-50 text-purple-600",
  };

  return (
    <Card className={cn("hover:shadow-lg transition-shadow duration-300 border-none shadow-sm", className)}>
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div className={cn("p-3 rounded-xl", colorStyles[color])}>
            <Icon className="w-6 h-6" />
          </div>
          {trend && (
            <div className={cn(
              "text-xs font-semibold px-2 py-1 rounded-full",
              trend === "up" ? "bg-green-100 text-green-700" : 
              trend === "down" ? "bg-red-100 text-red-700" : "bg-slate-100 text-slate-700"
            )}>
              {trend === "up" ? "↑" : trend === "down" ? "↓" : "•"} {trendValue}
            </div>
          )}
        </div>
        
        <h3 className="text-3xl font-display font-bold text-slate-900 mb-1">{value}</h3>
        <p className="text-sm font-medium text-slate-500">{title}</p>
        {subtitle && <p className="text-xs text-slate-400 mt-2">{subtitle}</p>}
      </CardContent>
    </Card>
  );
}

import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  LogOut, 
  LayoutDashboard, 
  Store, 
  ShoppingBag, 
  Ship, 
  Sprout, 
  ShieldCheck, 
  CloudSun,
  Activity
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";

export function Sidebar({ className }: { className?: string }) {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  const role = user?.role;

  const links = [
    { 
      href: "/dashboard", 
      label: "Overview", 
      icon: LayoutDashboard,
      roles: ["all"] 
    },
    // Customer Links
    { 
      href: "/dashboard/customer", 
      label: "Marketplace", 
      icon: Store,
      roles: ["customer"] 
    },
    { 
      href: "/dashboard/orders", 
      label: "My Orders", 
      icon: ShoppingBag,
      roles: ["customer"] 
    },
    // Fisherman Links
    { 
      href: "/dashboard/fisherman", 
      label: "My Catches", 
      icon: Ship,
      roles: ["fisherman"] 
    },
    { 
      href: "/dashboard/weather", 
      label: "Weather", 
      icon: CloudSun,
      roles: ["fisherman"] 
    },
    // Farmer Links
    { 
      href: "/dashboard/farmer", 
      label: "Farm Status", 
      icon: Sprout,
      roles: ["farmer"] 
    },
    // Gov/NGO Links
    { 
      href: "/dashboard/analytics", 
      label: "Analytics", 
      icon: Activity,
      roles: ["government_ngo"] 
    },
    // Admin Links
    { 
      href: "/dashboard/admin", 
      label: "User Verification", 
      icon: ShieldCheck,
      roles: ["admin"] 
    },
  ];

  const filteredLinks = links.filter(link => 
    link.roles.includes("all") || (role && link.roles.includes(role))
  );

  return (
    <div className={cn("flex flex-col h-screen w-64 bg-slate-900 text-white border-r border-slate-800 fixed left-0 top-0 z-50", className)}>
      <div className="p-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-blue-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-blue-500/20">
            <span className="text-white font-bold text-xl">D</span>
          </div>
          <div>
            <h1 className="font-display font-bold text-lg tracking-tight">DFAP</h1>
            <p className="text-xs text-slate-400 font-medium uppercase tracking-wider">Platform</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        <p className="px-4 py-2 text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Menu</p>
        {filteredLinks.map((link) => {
          const isActive = location === link.href || (link.href !== "/dashboard" && location.startsWith(link.href));
          return (
            <Link key={link.href} href={link.href}>
              <div 
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 cursor-pointer group",
                  isActive 
                    ? "bg-primary text-primary-foreground shadow-lg shadow-primary/25" 
                    : "text-slate-400 hover:text-white hover:bg-slate-800"
                )}
              >
                <link.icon className={cn("w-5 h-5", isActive ? "text-white" : "text-slate-500 group-hover:text-white")} />
                <span className="font-medium text-sm">{link.label}</span>
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-800 bg-slate-900/50">
        <div className="flex items-center gap-3 px-4 mb-4">
          <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-xs font-bold">
            {user?.fullName?.charAt(0) || "U"}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">{user?.fullName || "User"}</p>
            <p className="text-xs text-slate-500 truncate capitalize">{user?.role?.replace("_", " & ") || "Guest"}</p>
          </div>
        </div>
        <Button 
          variant="ghost" 
          className="w-full justify-start text-slate-400 hover:text-red-400 hover:bg-red-950/30"
          onClick={() => logout()}
        >
          <LogOut className="w-4 h-4 mr-2" />
          Logout
        </Button>
      </div>
    </div>
  );
}

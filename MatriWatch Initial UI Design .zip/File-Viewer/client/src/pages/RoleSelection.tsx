import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { User, Anchor, Sprout, Building2, ShieldCheck, Loader2, ArrowRight } from "lucide-react";

const roles = [
  {
    id: "customer",
    label: "Customer",
    description: "Buy fresh fish and produce directly from the source.",
    icon: User,
    color: "bg-blue-500"
  },
  {
    id: "fisherman",
    label: "Fisherman",
    description: "Sell your catch, check weather, and access market prices.",
    icon: Anchor,
    color: "bg-teal-500"
  },
  {
    id: "farmer",
    label: "Fish Farmer",
    description: "Monitor water quality, manage inventory, and optimize yield.",
    icon: Sprout,
    color: "bg-green-500"
  },
  {
    id: "government_ngo",
    label: "Govt / NGO",
    description: "Monitor regional data, manage programs, and analytics.",
    icon: Building2,
    color: "bg-orange-500"
  },
  {
    id: "admin",
    label: "Admin",
    description: "System administration and user verification.",
    icon: ShieldCheck,
    color: "bg-purple-500"
  }
];

export default function RoleSelectionPage() {
  const [selectedRole, setSelectedRole] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    fullName: "",
    location: "",
    languagePreference: "bengali"
  });
  
  const { registerDetails, isRegistering } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRole) return;

    await registerDetails({
      role: selectedRole as any,
      ...formData
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-5xl mx-auto space-y-12">
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-display font-bold text-slate-900">Choose your Role</h1>
          <p className="text-xl text-slate-500 max-w-2xl mx-auto">
            Select the profile that best describes you to personalize your experience on the platform.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {roles.map((role) => (
            <Card 
              key={role.id}
              onClick={() => setSelectedRole(role.id)}
              className={cn(
                "cursor-pointer transition-all duration-300 hover:shadow-xl border-2 group relative overflow-hidden",
                selectedRole === role.id 
                  ? "border-primary shadow-primary/20 scale-[1.02]" 
                  : "border-transparent hover:border-slate-200"
              )}
            >
              <div className={cn("absolute inset-0 opacity-0 group-hover:opacity-5 transition-opacity", role.color)}></div>
              <CardContent className="p-6 text-center space-y-4 relative z-10">
                <div className={cn("w-16 h-16 mx-auto rounded-2xl flex items-center justify-center text-white shadow-lg", role.color)}>
                  <role.icon className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900 mb-2">{role.label}</h3>
                  <p className="text-sm text-slate-500 leading-relaxed">{role.description}</p>
                </div>
                <div className={cn(
                  "w-6 h-6 rounded-full border-2 mx-auto mt-4 flex items-center justify-center transition-colors",
                  selectedRole === role.id ? "border-primary bg-primary" : "border-slate-300"
                )}>
                  {selectedRole === role.id && <div className="w-2.5 h-2.5 bg-white rounded-full" />}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {selectedRole && (
          <div className="max-w-2xl mx-auto animate-enter">
            <Card className="shadow-lg border-t-4 border-t-primary">
              <CardContent className="p-8">
                <div className="mb-6">
                  <h2 className="text-2xl font-bold text-slate-900">Complete Profile</h2>
                  <p className="text-slate-500">Just a few more details to get you started.</p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="fullName">Full Name</Label>
                      <Input
                        id="fullName"
                        placeholder="Enter your full name"
                        value={formData.fullName}
                        onChange={(e) => setFormData(prev => ({ ...prev, fullName: e.target.value }))}
                        required
                        className="h-11"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="location">Location / District</Label>
                      <Input
                        id="location"
                        placeholder="e.g. Chittagong, Dhaka"
                        value={formData.location}
                        onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                        required
                        className="h-11"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="language">Preferred Language</Label>
                      <Select 
                        value={formData.languagePreference}
                        onValueChange={(val) => setFormData(prev => ({ ...prev, languagePreference: val }))}
                      >
                        <SelectTrigger className="h-11">
                          <SelectValue placeholder="Select Language" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="bengali">Bengali</SelectItem>
                          <SelectItem value="english">English</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full h-12 text-lg font-medium shadow-lg shadow-primary/25"
                    disabled={isRegistering}
                  >
                    {isRegistering ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Creating Profile...
                      </>
                    ) : (
                      <>
                        Get Started <ArrowRight className="w-5 h-5 ml-2" />
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}

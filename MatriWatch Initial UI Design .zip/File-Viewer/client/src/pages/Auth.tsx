import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, ArrowRight, ShieldCheck, Fish } from "lucide-react";

export default function AuthPage() {
  const [step, setStep] = useState<"mobile" | "otp">("mobile");
  const [mobileNumber, setMobileNumber] = useState("");
  const [otpCode, setOtpCode] = useState("");
  const { sendOtp, verifyOtp, isSendingOtp, isVerifyingOtp } = useAuth();
  const [, setLocation] = useLocation();

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await sendOtp({ mobileNumber });
      setStep("otp");
    } catch (error) {
      // Error handled in hook
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = await verifyOtp({ mobileNumber, otpCode });
      if (data.isNewUser || !data.user?.role) {
        setLocation("/role-selection");
      } else {
        setLocation("/dashboard");
      }
    } catch (error) {
      // Error handled in hook
    }
  };

  return (
    <div className="min-h-screen grid grid-cols-1 lg:grid-cols-2">
      {/* Left: Brand / Hero */}
      <div className="hidden lg:flex flex-col justify-center items-center bg-slate-900 text-white p-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-blue-900/20 z-0"></div>
        {/* Abstract background pattern */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary/20 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-400/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>

        <div className="relative z-10 max-w-lg text-center space-y-8">
          <div className="w-20 h-20 bg-gradient-to-tr from-primary to-blue-400 rounded-2xl mx-auto flex items-center justify-center shadow-2xl shadow-primary/30">
            <Fish className="w-10 h-10 text-white" />
          </div>
          
          <h1 className="text-5xl font-display font-bold leading-tight">
            Digital Fisheries & <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-200 to-white">Agriculture Platform</span>
          </h1>
          
          <p className="text-lg text-slate-300 font-light leading-relaxed">
            Empowering fishermen, farmers, and consumers with a unified digital ecosystem for sustainable growth.
          </p>

          <div className="grid grid-cols-2 gap-4 pt-8">
            <div className="bg-white/5 backdrop-blur-sm p-4 rounded-xl border border-white/10">
              <h3 className="font-bold text-xl mb-1">10k+</h3>
              <p className="text-sm text-slate-400">Active Farmers</p>
            </div>
            <div className="bg-white/5 backdrop-blur-sm p-4 rounded-xl border border-white/10">
              <h3 className="font-bold text-xl mb-1">$2M+</h3>
              <p className="text-sm text-slate-400">Trade Volume</p>
            </div>
          </div>
        </div>
      </div>

      {/* Right: Auth Form */}
      <div className="flex flex-col justify-center items-center p-6 bg-slate-50">
        <div className="w-full max-w-md space-y-8 animate-enter">
          <div className="text-center lg:text-left space-y-2">
            <h2 className="text-3xl font-display font-bold text-slate-900">Welcome Back</h2>
            <p className="text-slate-500">Sign in to access your dashboard</p>
          </div>

          <Card className="border-none shadow-xl shadow-slate-200/50 overflow-hidden">
            <CardContent className="p-8 space-y-6">
              {step === "mobile" ? (
                <form onSubmit={handleSendOtp} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="mobile" className="text-slate-700 font-medium">Mobile Number</Label>
                    <div className="relative">
                      <Input
                        id="mobile"
                        type="tel"
                        placeholder="01712345678"
                        className="pl-10 h-12 text-lg"
                        value={mobileNumber}
                        onChange={(e) => setMobileNumber(e.target.value)}
                        required
                        pattern="[0-9]{11}"
                      />
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">📞</span>
                    </div>
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full h-12 text-lg font-medium shadow-lg shadow-primary/25" 
                    disabled={isSendingOtp || mobileNumber.length < 11}
                  >
                    {isSendingOtp ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Sending OTP...
                      </>
                    ) : (
                      <>
                        Continue <ArrowRight className="w-5 h-5 ml-2" />
                      </>
                    )}
                  </Button>
                </form>
              ) : (
                <form onSubmit={handleVerifyOtp} className="space-y-6">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <Label htmlFor="otp" className="text-slate-700 font-medium">Enter OTP</Label>
                      <button 
                        type="button" 
                        onClick={() => setStep("mobile")}
                        className="text-sm text-primary hover:underline"
                      >
                        Change Number
                      </button>
                    </div>
                    <div className="relative">
                      <Input
                        id="otp"
                        type="text"
                        placeholder="123456"
                        className="pl-10 h-12 text-lg tracking-widest"
                        maxLength={6}
                        value={otpCode}
                        onChange={(e) => setOtpCode(e.target.value)}
                        required
                      />
                      <ShieldCheck className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                    </div>
                    <p className="text-xs text-slate-500 mt-2">
                      We sent a 6-digit code to <strong>{mobileNumber}</strong>
                    </p>
                  </div>

                  <Button 
                    type="submit" 
                    className="w-full h-12 text-lg font-medium shadow-lg shadow-primary/25" 
                    disabled={isVerifyingOtp || otpCode.length < 6}
                  >
                    {isVerifyingOtp ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Verifying...
                      </>
                    ) : (
                      "Verify & Login"
                    )}
                  </Button>
                </form>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

import { useAuth } from "@/hooks/use-auth";
import { Sidebar } from "@/components/layout/Sidebar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Search, ShoppingCart, Filter } from "lucide-react";

const products = [
  { id: 1, name: "Fresh Hilsa (Ilish)", price: "$12.50", unit: "per kg", image: "🐟", seller: "River Delta Fisheries", rating: 4.8 },
  { id: 2, name: "Tiger Prawns", price: "$18.00", unit: "per kg", image: "🦐", seller: "Bay Cultivators", rating: 4.9 },
  { id: 3, name: "Rui Fish (Rohu)", price: "$6.20", unit: "per kg", image: "🐠", seller: "Green Pond Farms", rating: 4.5 },
  { id: 4, name: "Live Crab", price: "$15.00", unit: "per kg", image: "🦀", seller: "Sundarban Catch", rating: 4.7 },
  { id: 5, name: "Catfish (Pangash)", price: "$4.50", unit: "per kg", image: "🦈", seller: "Local Pond", rating: 4.2 },
  { id: 6, name: "Dried Fish (Shutki)", price: "$22.00", unit: "per kg", image: "🐡", seller: "Cox's Bazar Dry", rating: 4.6 },
];

export default function CustomerDashboard() {
  const { user } = useAuth();

  return (
    <div className="flex min-h-screen bg-slate-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-8 animate-enter">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-display font-bold text-slate-900">Marketplace</h1>
            <p className="text-slate-500">Fresh from the source to your kitchen.</p>
          </div>
          <div className="flex gap-4">
             <div className="relative w-96">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                <Input placeholder="Search for fish, prawns..." className="pl-10 h-11 bg-white" />
             </div>
             <Button variant="outline" className="h-11 w-11 p-0">
               <Filter className="w-5 h-5" />
             </Button>
             <Button className="h-11 shadow-lg shadow-primary/20">
               <ShoppingCart className="w-5 h-5 mr-2" /> Cart (0)
             </Button>
          </div>
        </div>

        {/* Categories */}
        <div className="flex gap-4 mb-8 overflow-x-auto pb-4">
           {["All", "Sea Fish", "Freshwater", "Shellfish", "Dried Fish", "Frozen"].map((cat, i) => (
             <button 
               key={cat}
               className={`px-6 py-2 rounded-full font-medium whitespace-nowrap transition-all ${
                 i === 0 
                 ? "bg-primary text-white shadow-md shadow-primary/25" 
                 : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
               }`}
             >
               {cat}
             </button>
           ))}
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {products.map((product) => (
            <Card key={product.id} className="border-none shadow-sm hover:shadow-xl transition-all duration-300 group cursor-pointer overflow-hidden">
              <div className="h-48 bg-slate-100 flex items-center justify-center text-6xl group-hover:scale-105 transition-transform duration-500">
                {product.image}
              </div>
              <CardContent className="p-5">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-bold text-lg text-slate-900 line-clamp-1">{product.name}</h3>
                    <p className="text-xs text-slate-500">{product.seller}</p>
                  </div>
                  <div className="flex items-center text-xs font-bold bg-yellow-100 text-yellow-700 px-2 py-1 rounded">
                    ★ {product.rating}
                  </div>
                </div>
                
                <div className="flex justify-between items-end mt-4">
                  <div>
                    <p className="text-lg font-bold text-primary">{product.price}</p>
                    <p className="text-xs text-slate-400">{product.unit}</p>
                  </div>
                  <Button size="sm" className="opacity-0 group-hover:opacity-100 transition-opacity translate-y-2 group-hover:translate-y-0">
                    Add to Cart
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

import { useAuth } from "@/hooks/use-auth";
import { Sidebar } from "@/components/layout/Sidebar";
import { StatCard } from "@/components/dashboard/StatCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Users, ShieldCheck, AlertCircle, CheckCircle } from "lucide-react";

export default function AdminDashboard() {
  const { user } = useAuth();

  const pendingUsers = [
    { id: 1, name: "Rahim Uddin", role: "Fisherman", location: "Cox's Bazar", date: "2 mins ago" },
    { id: 2, name: "Karim Farms Ltd", role: "Farmer", location: "Khulna", date: "15 mins ago" },
    { id: 3, name: "Green NGO", role: "Government & NGO", location: "Dhaka", date: "1 hour ago" },
  ];

  return (
    <div className="flex min-h-screen bg-slate-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-8 animate-enter">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-display font-bold text-slate-900">Admin Console</h1>
            <p className="text-slate-500">System health and user management.</p>
          </div>
          <Badge className="bg-green-500 hover:bg-green-600 px-4 py-1 text-sm">System Healthy</Badge>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <StatCard title="Total Users" value="12,450" icon={Users} color="blue" />
          <StatCard title="Pending Verifications" value="45" icon={AlertCircle} color="orange" />
          <StatCard title="Verified Today" value="128" icon={CheckCircle} color="green" />
        </div>

        <Card className="shadow-sm border-none">
          <CardHeader>
            <CardTitle>Pending Verifications</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-slate-500 uppercase bg-slate-50/50 border-b">
                  <tr>
                    <th className="px-4 py-3 font-semibold">User Details</th>
                    <th className="px-4 py-3 font-semibold">Role</th>
                    <th className="px-4 py-3 font-semibold">Location</th>
                    <th className="px-4 py-3 font-semibold">Applied</th>
                    <th className="px-4 py-3 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {pendingUsers.map((u) => (
                    <tr key={u.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-4 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center font-bold text-xs text-slate-600">
                            {u.name.charAt(0)}
                          </div>
                          <span className="font-medium text-slate-900">{u.name}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <Badge variant="outline" className="capitalize">{u.role}</Badge>
                      </td>
                      <td className="px-4 py-4 text-slate-600">{u.location}</td>
                      <td className="px-4 py-4 text-slate-500">{u.date}</td>
                      <td className="px-4 py-4 text-right space-x-2">
                        <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700 hover:bg-red-50">Reject</Button>
                        <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white">Approve</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

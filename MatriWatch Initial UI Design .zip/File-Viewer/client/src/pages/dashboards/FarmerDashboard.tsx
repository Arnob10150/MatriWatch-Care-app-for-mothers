import { useAuth } from "@/hooks/use-auth";
import { Sidebar } from "@/components/layout/Sidebar";
import { StatCard } from "@/components/dashboard/StatCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Droplets, Thermometer, Sprout, Wind, Activity } from "lucide-react";

export default function FarmerDashboard() {
  const { user } = useAuth();

  return (
    <div className="flex min-h-screen bg-slate-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-8 animate-enter">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-display font-bold text-slate-900">Farm Overview</h1>
            <p className="text-slate-500">Real-time water quality and production metrics.</p>
          </div>
          <Button className="shadow-lg shadow-primary/20">
            + Add New Pond
          </Button>
        </div>

        {/* IoT Sensor Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard 
            title="Dissolved Oxygen" 
            value="6.5 mg/L" 
            subtitle="Optimal Range: 5-8 mg/L"
            icon={Wind} 
            color="blue" 
            trend="neutral"
            trendValue="Stable"
          />
          <StatCard 
            title="pH Level" 
            value="7.2" 
            subtitle="Neutral - Perfect"
            icon={Droplets} 
            color="green" 
          />
          <StatCard 
            title="Temperature" 
            value="28°C" 
            subtitle="Pond A - Surface"
            icon={Thermometer} 
            color="orange" 
            trend="up"
            trendValue="+1°C"
          />
          <StatCard 
            title="Ammonia" 
            value="0.02 ppm" 
            subtitle="Warning at > 0.05"
            icon={Activity} 
            color="purple" 
          />
        </div>

        {/* Pond Status Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <Card className="lg:col-span-2 shadow-sm border-none">
            <CardHeader>
              <CardTitle>Pond Management</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[1, 2, 3].map((pond) => (
                  <div key={pond} className="flex items-center p-4 bg-white border border-slate-100 rounded-xl hover:shadow-md transition-shadow">
                    <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600 mr-4">
                      <Sprout className="w-8 h-8" />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-bold text-slate-900">Pond #{pond} - Tilapia</h4>
                          <p className="text-sm text-slate-500">Stocked: 12 days ago • Est. Harvest: Nov 15</p>
                        </div>
                        <span className="px-3 py-1 bg-green-100 text-green-700 text-xs font-bold rounded-full">Healthy</span>
                      </div>
                      <div className="mt-3 flex gap-4 text-sm">
                        <span className="text-slate-600">Feed: <strong className="text-slate-900">12kg/day</strong></span>
                        <span className="text-slate-600">Size: <strong className="text-slate-900">0.5 acres</strong></span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions / Tips */}
          <Card className="shadow-sm border-none">
            <CardHeader>
              <CardTitle>Farmer's Assistant</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="p-4 bg-yellow-50 rounded-xl border border-yellow-100">
                <h5 className="font-bold text-yellow-800 mb-2">Feeding Schedule</h5>
                <p className="text-sm text-yellow-700 mb-3">Time for the afternoon feed in Pond #2.</p>
                <Button size="sm" variant="outline" className="border-yellow-200 text-yellow-800 hover:bg-yellow-100">Mark Done</Button>
              </div>

              <div className="p-4 bg-blue-50 rounded-xl border border-blue-100">
                <h5 className="font-bold text-blue-800 mb-2">Market Insight</h5>
                <p className="text-sm text-blue-700">Shrimp prices are up 5% this week due to high demand.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

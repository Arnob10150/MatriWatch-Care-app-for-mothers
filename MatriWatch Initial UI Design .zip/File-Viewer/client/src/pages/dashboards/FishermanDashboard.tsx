import { useAuth } from "@/hooks/use-auth";
import { Sidebar } from "@/components/layout/Sidebar";
import { StatCard } from "@/components/dashboard/StatCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Ship, CloudRain, DollarSign, Scale, AlertTriangle } from "lucide-react";

export default function FishermanDashboard() {
  const { user } = useAuth();

  return (
    <div className="flex min-h-screen bg-slate-50">
      <Sidebar />
      <div className="flex-1 ml-64 p-8 animate-enter">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-display font-bold text-slate-900">Good Morning, {user?.fullName?.split(" ")[0]}!</h1>
            <p className="text-slate-500">Here's what's happening on the water today.</p>
          </div>
          <Button variant="destructive" className="shadow-lg shadow-red-500/20 font-bold">
            <AlertTriangle className="w-4 h-4 mr-2" /> SOS Signal
          </Button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard 
            title="Total Catch" 
            value="1,240 kg" 
            icon={Scale} 
            color="blue" 
            trend="up" 
            trendValue="+12%" 
          />
          <StatCard 
            title="Earnings" 
            value="$4,250" 
            icon={DollarSign} 
            color="green" 
            trend="up" 
            trendValue="+8%" 
          />
          <StatCard 
            title="Active Trips" 
            value="3" 
            icon={Ship} 
            color="purple" 
          />
          <StatCard 
            title="Weather" 
            value="24°C" 
            subtitle="Light Rain Expected"
            icon={CloudRain} 
            color="orange" 
          />
        </div>

        {/* Main Content Area */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Recent Catches Table */}
          <Card className="lg:col-span-2 shadow-sm border-none">
            <CardHeader>
              <CardTitle>Recent Catches</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="text-xs text-slate-500 uppercase bg-slate-50/50 border-b">
                    <tr>
                      <th className="px-4 py-3 font-semibold">Date</th>
                      <th className="px-4 py-3 font-semibold">Type</th>
                      <th className="px-4 py-3 font-semibold">Weight</th>
                      <th className="px-4 py-3 font-semibold">Price/kg</th>
                      <th className="px-4 py-3 font-semibold text-right">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {[1, 2, 3, 4, 5].map((item) => (
                      <tr key={item} className="hover:bg-slate-50/50 transition-colors">
                        <td className="px-4 py-3 font-medium text-slate-900">Oct {20 + item}, 2024</td>
                        <td className="px-4 py-3 text-slate-600">Hilsa Fish</td>
                        <td className="px-4 py-3 text-slate-600">120 kg</td>
                        <td className="px-4 py-3 text-slate-600">$4.50</td>
                        <td className="px-4 py-3 font-bold text-slate-900 text-right">$540.00</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Weather Widget */}
          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-xl shadow-blue-500/20 border-none">
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-8">
                <div>
                  <h3 className="text-xl font-bold">Bay of Bengal</h3>
                  <p className="text-blue-100 text-sm">Chittagong Coast</p>
                </div>
                <CloudRain className="w-10 h-10 text-blue-200" />
              </div>
              
              <div className="text-center mb-8">
                <h2 className="text-6xl font-display font-bold">24°</h2>
                <p className="font-medium text-blue-100">Light Showers</p>
              </div>

              <div className="grid grid-cols-3 gap-4 text-center">
                <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
                  <p className="text-xs text-blue-200">Wind</p>
                  <p className="font-bold">12 km/h</p>
                </div>
                <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
                  <p className="text-xs text-blue-200">Humidity</p>
                  <p className="font-bold">78%</p>
                </div>
                <div className="bg-white/10 rounded-lg p-3 backdrop-blur-sm">
                  <p className="text-xs text-blue-200">Visibility</p>
                  <p className="font-bold">8 km</p>
                </div>
              </div>

              <div className="mt-6 p-3 bg-red-500/20 border border-red-400/30 rounded-lg flex items-center gap-3">
                <AlertTriangle className="w-5 h-5 text-red-200" />
                <p className="text-sm font-medium text-red-100">Strong winds expected at 4 PM</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

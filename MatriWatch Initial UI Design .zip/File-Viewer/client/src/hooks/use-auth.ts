import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type InsertUser } from "@shared/routes";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

// Helper for generic fetch errors
function handleFetchError(error: unknown) {
  if (error instanceof Error) return error.message;
  return "An unexpected error occurred";
}

export function useAuth() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  // GET Current User
  const { data: user, isLoading: isLoadingUser, error: userError } = useQuery({
    queryKey: [api.auth.me.path],
    queryFn: async () => {
      const res = await fetch(api.auth.me.path, { credentials: "include" });
      if (res.status === 401) return null;
      if (!res.ok) throw new Error("Failed to fetch user");
      return api.auth.me.responses[200].parse(await res.json());
    },
    retry: false,
  });

  // SEND OTP
  const sendOtpMutation = useMutation({
    mutationFn: async (data: { mobileNumber: string }) => {
      const validated = api.auth.sendOtp.input.parse(data);
      const res = await fetch(api.auth.sendOtp.path, {
        method: api.auth.sendOtp.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = api.auth.sendOtp.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to send OTP");
      }
      return api.auth.sendOtp.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      toast({
        title: "OTP Sent",
        description: "Please check your mobile device.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error Sending OTP",
        description: handleFetchError(error),
        variant: "destructive",
      });
    },
  });

  // VERIFY OTP
  const verifyOtpMutation = useMutation({
    mutationFn: async (data: { mobileNumber: string; otpCode: string }) => {
      const validated = api.auth.verifyOtp.input.parse(data);
      const res = await fetch(api.auth.verifyOtp.path, {
        method: api.auth.verifyOtp.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 400) {
          const error = api.auth.verifyOtp.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        if (res.status === 401) {
          const error = api.auth.verifyOtp.responses[401].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to verify OTP");
      }
      return api.auth.verifyOtp.responses[200].parse(await res.json());
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: [api.auth.me.path] });
      toast({
        title: "Login Successful",
        description: data.isNewUser ? "Welcome! Please complete your profile." : "Welcome back!",
      });
    },
    onError: (error) => {
      toast({
        title: "Verification Failed",
        description: handleFetchError(error),
        variant: "destructive",
      });
    },
  });

  // REGISTER DETAILS
  const registerDetailsMutation = useMutation({
    mutationFn: async (data: Partial<InsertUser>) => {
      const validated = api.auth.registerDetails.input.parse(data);
      const res = await fetch(api.auth.registerDetails.path, {
        method: api.auth.registerDetails.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 400) {
          const error = api.auth.registerDetails.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        if (res.status === 401) throw new Error("Unauthorized");
        throw new Error("Failed to update profile");
      }
      return api.auth.registerDetails.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.auth.me.path] });
      toast({
        title: "Profile Updated",
        description: "Your account is ready to use.",
      });
      setLocation("/dashboard");
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: handleFetchError(error),
        variant: "destructive",
      });
    },
  });

  // LOGOUT
  const logoutMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch(api.auth.logout.path, {
        method: api.auth.logout.method,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Logout failed");
    },
    onSuccess: () => {
      queryClient.setQueryData([api.auth.me.path], null);
      setLocation("/");
      toast({
        title: "Logged Out",
        description: "See you next time!",
      });
    },
  });

  return {
    user,
    isLoadingUser,
    sendOtp: sendOtpMutation.mutateAsync,
    isSendingOtp: sendOtpMutation.isPending,
    verifyOtp: verifyOtpMutation.mutateAsync,
    isVerifyingOtp: verifyOtpMutation.isPending,
    registerDetails: registerDetailsMutation.mutateAsync,
    isRegistering: registerDetailsMutation.isPending,
    logout: logoutMutation.mutate,
  };
}

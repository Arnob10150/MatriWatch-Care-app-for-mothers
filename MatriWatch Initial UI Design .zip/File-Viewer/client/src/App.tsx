import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";

// Pages
import AuthPage from "@/pages/Auth";
import RoleSelectionPage from "@/pages/RoleSelection";
import CustomerDashboard from "@/pages/dashboards/CustomerDashboard";
import FishermanDashboard from "@/pages/dashboards/FishermanDashboard";
import FarmerDashboard from "@/pages/dashboards/FarmerDashboard";
import AdminDashboard from "@/pages/dashboards/AdminDashboard";
import NotFound from "@/pages/not-found";

// Route Guard Component
function ProtectedRoute({ 
  component: Component, 
  allowedRoles = [] 
}: { 
  component: React.ComponentType, 
  allowedRoles?: string[] 
}) {
  const { user, isLoadingUser } = useAuth();

  if (isLoadingUser) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-slate-50">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return <Redirect to="/" />;
  }

  // If user has no role, force them to role selection
  if (!user.role && window.location.pathname !== "/role-selection") {
    return <Redirect to="/role-selection" />;
  }

  // If roles are restricted and user doesn't match
  if (allowedRoles.length > 0 && user.role && !allowedRoles.includes(user.role)) {
    // Redirect to their correct dashboard
    return <Redirect to={`/dashboard/${user.role}`} />;
  }

  return <Component />;
}

function DashboardRouter() {
  const { user, isLoadingUser } = useAuth();

  if (isLoadingUser) return null;

  if (!user?.role) return <Redirect to="/role-selection" />;

  // Main /dashboard redirect logic
  switch (user.role) {
    case "customer": return <Redirect to="/dashboard/customer" />;
    case "fisherman": return <Redirect to="/dashboard/fisherman" />;
    case "farmer": return <Redirect to="/dashboard/farmer" />;
    case "government_ngo": return <Redirect to="/dashboard/analytics" />; // Using Analytics for Gov
    case "admin": return <Redirect to="/dashboard/admin" />;
    default: return <Redirect to="/role-selection" />;
  }
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={AuthPage} />
      
      {/* Role Selection - Protected but for users without roles */}
      <Route path="/role-selection">
        <ProtectedRoute component={RoleSelectionPage} />
      </Route>

      {/* Main Dashboard Redirector */}
      <Route path="/dashboard">
        <ProtectedRoute component={DashboardRouter} />
      </Route>

      {/* Role Specific Dashboards */}
      <Route path="/dashboard/customer">
        <ProtectedRoute component={CustomerDashboard} allowedRoles={["customer"]} />
      </Route>

      <Route path="/dashboard/fisherman">
        <ProtectedRoute component={FishermanDashboard} allowedRoles={["fisherman"]} />
      </Route>

      <Route path="/dashboard/farmer">
        <ProtectedRoute component={FarmerDashboard} allowedRoles={["farmer"]} />
      </Route>

      <Route path="/dashboard/admin">
        <ProtectedRoute component={AdminDashboard} allowedRoles={["admin"]} />
      </Route>
      
      {/* Gov/NGO Dashboard Placeholder re-using Admin layout for demo simplicity or specific component */}
      <Route path="/dashboard/analytics">
        <ProtectedRoute component={AdminDashboard} allowedRoles={["government_ngo", "admin"]} />
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;

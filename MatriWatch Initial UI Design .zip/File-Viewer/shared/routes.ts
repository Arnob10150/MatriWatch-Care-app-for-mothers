import { z } from 'zod';
import { insertUserSchema, users } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
  unauthorized: z.object({
    message: z.string(),
  }),
};

export const api = {
  auth: {
    sendOtp: {
      method: 'POST' as const,
      path: '/api/auth/send-otp',
      input: z.object({
        mobileNumber: z.string().min(11, "Mobile number must be at least 11 digits"),
      }),
      responses: {
        200: z.object({ message: z.string(), expiresAt: z.string() }),
        400: errorSchemas.validation,
      },
    },
    verifyOtp: {
      method: 'POST' as const,
      path: '/api/auth/verify-otp',
      input: z.object({
        mobileNumber: z.string(),
        otpCode: z.string().length(6, "OTP must be 6 digits"),
      }),
      responses: {
        200: z.object({ message: z.string(), user: z.custom<typeof users.$inferSelect>().optional(), isNewUser: z.boolean() }),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
    registerDetails: {
      method: 'POST' as const,
      path: '/api/auth/register-details',
      input: insertUserSchema.pick({ fullName: true, role: true, location: true, languagePreference: true }),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        400: errorSchemas.validation,
        401: errorSchemas.unauthorized,
      },
    },
    logout: {
      method: 'POST' as const,
      path: '/api/auth/logout',
      responses: {
        200: z.object({ message: z.string() }),
      },
    },
    me: {
      method: 'GET' as const,
      path: '/api/user/me',
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.unauthorized,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

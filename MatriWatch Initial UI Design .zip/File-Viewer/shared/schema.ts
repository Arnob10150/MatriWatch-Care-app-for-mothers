import { pgTable, text, serial, boolean, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const userRoles = ["customer", "fisherman", "farmer", "government_ngo", "admin"] as const;

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  mobileNumber: text("mobile_number").unique().notNull(),
  fullName: text("full_name"),
  role: text("role", { enum: userRoles }),
  location: text("location"),
  languagePreference: text("language_preference").default("bengali"),
  profilePicture: text("profile_picture"),
  isVerified: boolean("is_verified").default(false),
  accountStatus: text("account_status").default("active"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const otpVerifications = pgTable("otp_verifications", {
  id: serial("id").primaryKey(),
  mobileNumber: text("mobile_number").notNull(),
  otpCode: text("otp_code").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  isVerified: boolean("is_verified").default(false),
  attempts: integer("attempts").default(0),
});

export const insertUserSchema = createInsertSchema(users).omit({ 
  id: true, 
  createdAt: true,
  isVerified: true,
  accountStatus: true
});

export const insertOtpSchema = createInsertSchema(otpVerifications).omit({
  id: true,
  isVerified: true,
  attempts: true
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type OtpVerification = typeof otpVerifications.$inferSelect;
